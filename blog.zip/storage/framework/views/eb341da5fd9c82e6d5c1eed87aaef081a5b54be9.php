<?php $__env->startSection('content'); ?>

    <?php echo $__env->make('admin.includes.errors', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>


    <div class="card">

        <div class="card-header">

            Create a new tag

        </div>

        <div class="card-body">

            <form action="<?php echo e(route('tags.store')); ?>" method="post">
                <?php echo e(csrf_field()); ?>


                <div class="form-group">

                    <label for="tag">Tag</label>

                    <input type="text" name="tag" class="form-control">

                </div>

                <div class="form-group text-center">

                    <button class="btn btn-success" type="submit">

                        Store tag

                    </button>

                </div>

            </form>

        </div>

    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\larka\blog\resources\views/admin/tags/create.blade.php ENDPATH**/ ?>